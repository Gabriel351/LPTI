#include "dadoslogin.h"
#include "QString"

int perm;
QString login, nome1;

DadosLogin::DadosLogin()
{
}




