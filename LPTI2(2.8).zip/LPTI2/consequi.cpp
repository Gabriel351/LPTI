#include "consequi.h"
#include "ui_consequi.h"
#include "consultaprincipal.h"
#include "menucadasoption.h"
#include "consultaprincipal.h"
#include "dadoslogin.h"

ConsEqui::ConsEqui(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ConsEqui)
{
    ui->setupUi(this);
}

ConsEqui::~ConsEqui()
{
    delete ui;
}

void ConsEqui::on_pushButton_4_clicked()
{
    ConsultaPrincipal consultaprincipal;
    consultaprincipal.setModal(true);
    consultaprincipal.exec();
}

void ConsEqui::on_cadastro_2_clicked()
{
    if (perm != 11 && perm != 12 && perm != 13) {
        MenuCadasOption menucadasoption;
        menucadasoption.setModal(true);
        this->close();
        menucadasoption.exec();
    }
}

void ConsEqui::on_consulta_2_clicked()
{
    if  (perm != 6 && perm != 6 && perm != 9 && perm != 10 && perm != 12 && perm != 14 && perm != 15) {
        ConsultaPrincipal consultaprincipal;
        consultaprincipal.setModal(true);
        this->close();
        consultaprincipal.exec();
    }
}
