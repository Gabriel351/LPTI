#include "consusuarios.h"
#include "ui_consusuarios.h"
#include "consultaprincipal.h"
/*#include "QPrinter"
#include "QPainter"*/

ConsUsuarios::ConsUsuarios(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ConsUsuarios)
{
    ui->setupUi(this);
}

ConsUsuarios::~ConsUsuarios()
{
    delete ui;
}

void ConsUsuarios::on_pushButton_3_clicked()
{
    ConsultaPrincipal consultaprincipal;
    consultaprincipal.setModal(true);
    consultaprincipal.exec();
}



void ConsUsuarios::on_pushButton_clicked()
{
    /*
    QPainter painter;
    QPrinter printer(QPrinter::HighResolution);
    printer.setOutputFormat(QPrinter::PdfFormat);
    printer.setOutputFileName("teste.pdf");
            painter.begin(&printer);
            double xscale = printer.pageRect().width()/double(ui->tableWidget->width());
            double yscale = printer.pageRect().height()/double(ui->tableWidget->height());
            double scale = qMin(xscale, yscale);
            painter.translate(printer.paperRect().x() + printer.pageRect().width()/2,
                               printer.paperRect().y() + printer.pageRect().height()/2);
            painter.scale(scale, scale);
            painter.translate(-width()/2, -height()/2);

            ui->tableWidget->render(&painter);
            painter.end();
            */
}
