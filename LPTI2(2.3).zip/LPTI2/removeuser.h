#ifndef REMOVEUSER_H
#define REMOVEUSER_H

#include <QDialog>
#include <QCompleter>


namespace Ui {
class RemoveUser;

}

class RemoveUser : public QDialog
{
    Q_OBJECT

public:
    explicit RemoveUser(QWidget *parent = 0);
    ~RemoveUser();

private slots:
     void on_pushButton_clicked();

     void on_edit_Siape_textChanged(const QString &arg1);

     void on_bnt_Confirma_clicked();

private:
    Ui::RemoveUser *ui;
    QCompleter *StringCompleter;

};

#endif // REMOVEUSER_H
