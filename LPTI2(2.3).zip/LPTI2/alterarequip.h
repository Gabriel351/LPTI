#ifndef ALTERAREQUIP_H
#define ALTERAREQUIP_H

#include <QDialog>
#include <QCompleter>

namespace Ui {
class AlterarEquip;
}

class AlterarEquip : public QDialog
{
    Q_OBJECT

public:
    explicit AlterarEquip(QWidget *parent = 0);
    ~AlterarEquip();

private slots:
     void on_pushButton_3_clicked();

     void on_cod_textChanged();

     void on_btn_confirma_clicked();

     /*void on_cadastrar_clicked();

     void on_remover_clicked();

     void on_menu_clicked();*/

private:
    Ui::AlterarEquip *ui;
    QCompleter *StringCompleter;
};

#endif // ALTERAREQUIP_H
