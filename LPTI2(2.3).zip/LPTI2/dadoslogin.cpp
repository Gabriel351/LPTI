#include "dadoslogin.h"
#include "QString"

int perm;
QString login;

DadosLogin::DadosLogin()
{
}




