#include "consusuarios.h"
#include "ui_consusuarios.h"
#include "consultaprincipal.h"
#include "QSqlQuery"
#include "nomesiapeproxmodel.h"
/*#include "QPrinter"
#include "QPainter"*/

ConsUsuarios::ConsUsuarios(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ConsUsuarios)
{
    ui->setupUi(this);

    //Trazer os dados da tabela
    modUsuario = new QSqlRelationalTableModel(this, cn::db());
    modUsuario->setTable("Usuario");
    modUsuario->select();
    modUsuario->setHeaderData(1, Qt::Horizontal, QObject::tr("Nome"));
    modUsuario->setHeaderData(2, Qt::Horizontal, QObject::tr("E-mail"));
    modUsuario->setHeaderData(4, Qt::Horizontal, QObject::tr("SIAPE"));

    //Filtro

    //modUsuario->setFilter(QString("Nome like '%sfwess%' "));

    ui->tableView->setModel(modUsuario);
    ui->tableView->hideColumn(0);
    ui->tableView->hideColumn(3);
    ui->tableView->hideColumn(5);
    ui->tableView->hideColumn(6);

   /* QStandardItemModel sourceModel;
    NomeSiapeProxyModel filterModel;
        filterModel.setSourceModel(&sourceModel);
        //ui->tableView->setModel(&filterModel);

    QObject::connect(ui->nome, &QLineEdit::textChanged,
                        &filterModel, &NomeSiapeProxyModel::setNameFilter);
       QObject::connect(ui->siape, &QLineEdit::textChanged,
                        &filterModel, &NomeSiapeProxyModel::setYearFilter);*/

}

ConsUsuarios::~ConsUsuarios()
{
    delete ui;
}

void ConsUsuarios::on_pushButton_3_clicked()
{
    ConsultaPrincipal consultaprincipal;
    consultaprincipal.setModal(true);
    consultaprincipal.exec();
}



void ConsUsuarios::on_pushButton_clicked()
{
    /*
    QPainter painter;
    QPrinter printer(QPrinter::HighResolution);
    printer.setOutputFormat(QPrinter::PdfFormat);
    printer.setOutputFileName("teste.pdf");
            painter.begin(&printer);
            double xscale = printer.pageRect().width()/double(ui->tableWidget->width());
            double yscale = printer.pageRect().height()/double(ui->tableWidget->height());
            double scale = qMin(xscale, yscale);
            painter.translate(printer.paperRect().x() + printer.pageRect().width()/2,
                               printer.paperRect().y() + printer.pageRect().height()/2);
            painter.scale(scale, scale);
            painter.translate(-width()/2, -height()/2);

            ui->tableWidget->render(&painter);
            painter.end();
            */
}

void ConsUsuarios::on_lineEdit_2_textChanged(const QString &arg1)
{

}

void ConsUsuarios::on_nome_textChanged(const QString &arg1)
{
    QString filter_nome = ui->nome->text();
    QString filter_siape = ui->siape->text();
    QString filter_email = ui->email->text();
    modUsuario->setFilter(QString("Nome like '%"+filter_nome+"%' and SIAPE like '%"+filter_siape+"%' "
    "and Email like '%"+filter_email+"%' "));
    ui->tableView->setModel(modUsuario);
}

void ConsUsuarios::on_siape_textChanged(const QString &arg1)
{
    QString filter_nome = ui->nome->text();
    QString filter_siape = ui->siape->text();
    QString filter_email = ui->email->text();
    modUsuario->setFilter(QString("Nome like '%"+filter_nome+"%' and SIAPE like '%"+filter_siape+"%' "
    "and Email like '%"+filter_email+"%' "));
    ui->tableView->setModel(modUsuario);
}

void ConsUsuarios::on_email_textChanged(const QString &arg1)
{
    QString filter_nome = ui->nome->text();
    QString filter_siape = ui->siape->text();
    QString filter_email = ui->email->text();
    modUsuario->setFilter(QString("Nome like '%"+filter_nome+"%' and SIAPE like '%"+filter_siape+"%' "
    "and Email like '%"+filter_email+"%' "));
    ui->tableView->setModel(modUsuario);
}
