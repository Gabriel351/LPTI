#ifndef DADOSLOGIN_H
#define DADOSLOGIN_H
#include "QString"

extern int perm;
extern QString login,nome1;

class DadosLogin
{
public:
    DadosLogin();

};



#endif // DADOSLOGIN_H
