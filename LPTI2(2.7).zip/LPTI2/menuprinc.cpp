#include "menuprinc.h"
#include "ui_menuprinc.h"
#include "menucadasoption.h"
#include "menuempres.h"
#include "consultaprincipal.h"
#include "login.h"
#include "dadoslogin.h"
#include <QApplication>


MenuPrinc::MenuPrinc(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MenuPrinc)
{
    ui->setupUi(this);
    QVariant a = perm;
    if (perm != 11 && perm != 12 && perm != 13) {
        ui->cadastro->setStyleSheet("background-color: rgb(0,255,0)");
    } else {
        ui->cadastro->setStyleSheet("background-color: rgb(105,105,105)");
    }

    if (perm != 3 && perm != 6 && perm != 9 && perm != 10 && perm != 12 && perm != 14 && perm != 15) {
        ui->consulta->setStyleSheet("background-color: rgb(0,255,0)");
    } else {
        ui->consulta->setStyleSheet("background-color: rgb(105,105,105)");
    }

    if (perm != 2 && perm != 6 && perm != 7 && perm != 8 && perm != 13 && perm != 14 && perm != 15) {
        ui->emprestimo->setStyleSheet("background-color: rgb(105,105,105)");
    } else {
        ui->emprestimo->setStyleSheet("background-color: rgb(105,105,105)");
    }

    QPixmap bkgnd("/LPTI2/img/madeira.jpg");
       bkgnd = bkgnd.scaled(this->size(), Qt::IgnoreAspectRatio);
       QPalette palette;
       palette.setBrush(QPalette::Background, bkgnd);
       this->setPalette(palette);

       ui->label_nome->setText(nome1);
       ui->label_siape->setText(login);

}

MenuPrinc::~MenuPrinc()
{
    delete ui;
}

void MenuPrinc::on_cadastro_clicked()
{
    if (perm != 11 && perm != 12 && perm != 13) {
        MenuCadasOption menucadasoption;
        menucadasoption.setModal(true);
        this->close();
        menucadasoption.exec();
    }
}

void MenuPrinc::on_emprestimo_clicked()
{
    if (perm != 2 && perm != 6 && perm != 7 && perm != 8 && perm != 13 && perm != 14 && perm != 15) {
        MenuEmpres menuemp;
        menuemp.setModal(true);
        this->close();
        menuemp.exec();
    }
}

void MenuPrinc::on_consulta_clicked()
{
    if (perm != 6 && perm != 6 && perm != 9 && perm != 10 && perm != 12 && perm != 14 && perm != 15) {
       ConsultaPrincipal consultaprincipal;
        consultaprincipal.setModal(true);
        this->close();
        consultaprincipal.exec();
    }
}


void MenuPrinc::on_desconectar_clicked()
{
    Login* inicio = new Login();
    this->close();
    inicio->show();
}

void MenuPrinc::on_cadastro_2_clicked()
{
    if (perm != 11 && perm != 12 && perm != 13) {
        MenuCadasOption menucadasoption;
        menucadasoption.setModal(true);
        this->close();
        menucadasoption.exec();
    }
}



void MenuPrinc::on_consulta_2_clicked()
{
    if (perm != 6 && perm != 6 && perm != 9 && perm != 10 && perm != 12 && perm != 14 && perm != 15) {
       ConsultaPrincipal consultaprincipal;
        consultaprincipal.setModal(true);
        this->close();
        consultaprincipal.exec();
    }
}



void MenuPrinc::on_emprestimo_2_clicked()
{
    if (perm != 2 && perm != 6 && perm != 7 && perm != 8 && perm != 13 && perm != 14 && perm != 15) {
        MenuEmpres menuemp;
        menuemp.setModal(true);
        this->close();
        menuemp.exec();
    }
}
