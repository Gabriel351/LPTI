#ifndef EMAIL_H
#define EMAIL_H


class Email
{
public:
    Email();
};

#endif // EMAIL_H