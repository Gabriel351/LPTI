#include "conslab.h"
#include "ui_conslab.h"
#include "consultaprincipal.h"
#include "menucadasoption.h"
#include "consultaprincipal.h"
#include "dadoslogin.h"
#include "QSqlQuery"
#include "nomesiapeproxmodel.h"
#include <cn.h>

ConsLab::ConsLab(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ConsLab)
{
    ui->setupUi(this);

    //Trazer os dados da tabela
    modLab = new QSqlRelationalTableModel(this, cn::db());
    modLab->setTable("Laboratorio");
    modLab->select();
    modLab->setHeaderData(1, Qt::Horizontal, QObject::tr("Prof. Responsável"));
    modLab->setHeaderData(2, Qt::Horizontal, QObject::tr("Ténico do Laboratório"));
    modLab->setHeaderData(3, Qt::Horizontal, QObject::tr("Código"));
    modLab->setHeaderData(4, Qt::Horizontal, QObject::tr("Localização"));

    //Filtro

    //modUsuario->setFilter(QString("Nome like '%sfwess%' "));

    ui->tableView->setModel(modLab);
    /*ui->tableView->hideColumn(0);
    ui->tableView->hideColumn(3);
    ui->tableView->hideColumn(5);
    ui->tableView->hideColumn(6);*/
}

ConsLab::~ConsLab()
{
    delete ui;
}

void ConsLab::on_pushButton_4_clicked()
{
    ConsultaPrincipal consultaprincipal;
    consultaprincipal.setModal(true);
    consultaprincipal.exec();
}

void ConsLab::on_cadastro_2_clicked()
{
    if (perm != 11 && perm != 12 && perm != 13) {
        MenuCadasOption menucadasoption;
        menucadasoption.setModal(true);
        this->close();
        menucadasoption.exec();
    }
}

void ConsLab::on_consulta_2_clicked()
{
    if  (perm != 6 && perm != 6 && perm != 9 && perm != 10 && perm != 12 && perm != 14 && perm != 15) {
        ConsultaPrincipal consultaprincipal;
        consultaprincipal.setModal(true);
        this->close();
        consultaprincipal.exec();
    }
}

void ConsLab::on_lineEdit_ProfResponsavel_textChanged(const QString &arg1)
{
    QString filter_proResponsavel = ui->lineEdit_ProfResponsavel->text();
    QString filter_tecLab = ui->lineEdit_TecnicodeLab->text();
    QString filter_Localizacao = ui->lineEdit_Localizacao->text();
    QString filter_Codigo = ui->lineEdit_Codigo->text();
    modLab->setFilter(QString("Professor like '%"+filter_proResponsavel+"%' and Tecnico like '%"+filter_tecLab+"%' "
    "and Localizacao like '%"+filter_Localizacao+"%' and IdLaboratorio like '%"+filter_Codigo+"%' "));
    ui->tableView->setModel(modLab);
}

void ConsLab::on_lineEdit_TecnicodeLab_textChanged(const QString &arg1)
{
    QString filter_proResponsavel = ui->lineEdit_ProfResponsavel->text();
    QString filter_tecLab = ui->lineEdit_TecnicodeLab->text();
    QString filter_Localizacao = ui->lineEdit_Localizacao->text();
    QString filter_Codigo = ui->lineEdit_Codigo->text();
    modLab->setFilter(QString("Professor like '%"+filter_proResponsavel+"%' and Tecnico like '%"+filter_tecLab+"%' "
    "and Localizacao like '%"+filter_Localizacao+"%' and IdLaboratorio like '%"+filter_Codigo+"%' "));
    ui->tableView->setModel(modLab);
}

void ConsLab::on_lineEdit_Localizacao_textChanged(const QString &arg1)
{
    QString filter_proResponsavel = ui->lineEdit_ProfResponsavel->text();
    QString filter_tecLab = ui->lineEdit_TecnicodeLab->text();
    QString filter_Localizacao = ui->lineEdit_Localizacao->text();
    QString filter_Codigo = ui->lineEdit_Codigo->text();
    modLab->setFilter(QString("Professor like '%"+filter_proResponsavel+"%' and Tecnico like '%"+filter_tecLab+"%' "
    "and Localizacao like '%"+filter_Localizacao+"%' and IdLaboratorio like '%"+filter_Codigo+"%' "));
    ui->tableView->setModel(modLab);
}

void ConsLab::on_lineEdit_Codigo_textChanged(const QString &arg1)
{
    QString filter_proResponsavel = ui->lineEdit_ProfResponsavel->text();
    QString filter_tecLab = ui->lineEdit_TecnicodeLab->text();
    QString filter_Localizacao = ui->lineEdit_Localizacao->text();
    QString filter_Codigo = ui->lineEdit_Codigo->text();
    modLab->setFilter(QString("Professor like '%"+filter_proResponsavel+"%' and Tecnico like '%"+filter_tecLab+"%' "
    "and Localizacao like '%"+filter_Localizacao+"%' and IdLaboratorio like '%"+filter_Codigo+"%' "));
    ui->tableView->setModel(modLab);
}
