#include "conslab.h"
#include "ui_conslab.h"
#include "consultaprincipal.h"
#include "menucadasoption.h"
#include "consultaprincipal.h"
#include "dadoslogin.h"
#include "QSqlQuery"
#include <QSqlRelationalDelegate>
#include "nomesiapeproxmodel.h"
#include <cn.h>
#include "alterarlab.h"
#include "removelab.h"

ConsLab::ConsLab(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ConsLab)
{
    ui->setupUi(this);

    ui->tableView->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ui->tableView, SIGNAL(customContextMenuRequested(QPoint)),
    SLOT(customMenuRequested(QPoint)));

    //Trazer os dados da tabela
    modLab = new QSqlRelationalTableModel(this, QSqlDatabase::database());
    modLab->setTable("laboratorio");
    modLab->setRelation(5, QSqlRelation("usuario", "CodUsuario", "Nome"));
    modLab->setRelation(4, QSqlRelation("usuario", "CodUsuario", "Nome"));

    modLab->setJoinMode(QSqlRelationalTableModel::LeftJoin);
    modLab->setHeaderData(1, Qt::Horizontal, QObject::tr("Descrição"));
    modLab->setHeaderData(2, Qt::Horizontal, QObject::tr("Localização"));
    modLab->setHeaderData(3, Qt::Horizontal, QObject::tr("Código"));
    modLab->setHeaderData(4, Qt::Horizontal, QObject::tr("Técnico"));
    modLab->setHeaderData(5, Qt::Horizontal, QObject::tr("Professor"));
    modLab->setFilter(QString("laboratorio.Estado = true "));

    modLab->select();

    ui->tableView->setModel(modLab);
    ui->tableView->hideColumn(0);
    ui->tableView->hideColumn(1);
    ui->tableView->hideColumn(6);
    QHeaderView *headerView = ui->tableView->horizontalHeader();
    headerView->swapSections(2, 3);
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);
}


ConsLab::~ConsLab()
{
    delete ui;
}

void ConsLab::on_pushButton_4_clicked()
{
    ConsultaPrincipal consultaprincipal;
    consultaprincipal.setModal(true);
    consultaprincipal.exec();
}

void ConsLab::on_cadastro_2_clicked()
{
    if (perm != 11 && perm != 12 && perm != 13) {
        MenuCadasOption menucadasoption;
        menucadasoption.setModal(true);
        this->close();
        menucadasoption.exec();
    }
}

void ConsLab::on_consulta_2_clicked()
{
    if  (perm != 6 && perm != 6 && perm != 9 && perm != 10 && perm != 12 && perm != 14 && perm != 15) {
        ConsultaPrincipal consultaprincipal;
        consultaprincipal.setModal(true);
        this->close();
        consultaprincipal.exec();
    }
}


QString getUsuario(QString usuario, int cargo) {
    QSqlQuery query;
    int  count = 0;
    QString num = "", tam;
    QVariant tipo;
    QString user = "(", contagem = "";

    //chave estrangeira filtro
    if (usuario.size() != 0) {
        query.prepare("select CodUsuario from usuario where Nome like '%"+usuario+"%' ");
       if (query.exec()) {

           //a ideia é juntar todos os CodUsuario(int) em uma string->num, e pega o tamanho de cada CodUsuario->tipo, e
           //colocar os tamanho em outra string->contagem para lógica mais abaixo
            while (query.next()) {
                count++;
                num += query.value(0).toString();
                tam = query.value(0).toString();
                tipo = tam.size();
                // erro se ja foi adicionado 1000000000 de usuários :p
                contagem += tipo.toString();
            }

          if (count != 0) {
             int a = 0;
             for (int i = 0; i < count; i++) {
                 //a ideia é pegar cada CodUsuario retornado que está na string->num e fazer um 'like' para cada um,
                 //formando uma grande string->user com todos os 'like'
                 //o contagem é necessário para quando o tamanho do CodUsuario for maior que 1(11,12,13,100,200...),
                 //em vez de pegar o valor da string num de uma unica posição, pegar de 2(10) ou 3(100) e assim por diante
                 //como quando pega o valor de mais de uma posição é necessário pular 2 ou 3 posições,
                 //dependendo do tamanho do valor pego, é preciso haver uma variavel para pular essas posições->int a
                 //OBS: usar igual em vez de like, pois se tiver o numero 17 e 117, por exemplo, irá retornar
                 // tanto o 117 como o 17, caso o numero seja o 17
                 tipo = contagem.mid(i,1);
                 if (cargo == 1) {
                     user += "Tecnico="+num.mid(a,tipo.toInt())+" or ";
                     a += tipo.toInt();
                 }
                 if (cargo == 2) {
                     user += "Professor="+num.mid(a,tipo.toInt())+" or ";
                     a += tipo.toInt();
                 }
             }
             user.remove(user.size() - 3, 3);
             user += ")";
             return user;
           } else {
              //nenhum filtro encontrado

              return "CodLaboratorio = -1";
          }
     }
   } else {
        //filtro em branco
        if (cargo == 1) {
            return "(Tecnico like '%%' or Tecnico is null)";
        } else {
            return "Professor like '%%'";
        }
    }
}



void ConsLab::on_lineEdit_ProfResponsavel_textChanged(const QString &arg1)
{
    QString filter_proResponsavel = ui->lineEdit_ProfResponsavel->text();
    QString filter_tecLab = ui->lineEdit_TecnicodeLab->text();
    QString filter_Localizacao = ui->lineEdit_Localizacao->text();
    QString filter_Codigo = ui->lineEdit_Codigo->text();
    QString prof, tec;

     tec = getUsuario(filter_tecLab,1);
     prof = getUsuario(filter_proResponsavel,2);

     modLab->setFilter(QString(""+prof+" and "+tec+" and IdLaboratorio like '%"+filter_Codigo+"%' "
     "and Localizacao like '%"+filter_Localizacao+"%' and laboratorio.Estado=true "));

     ui->tableView->setModel(modLab);
}

void ConsLab::on_lineEdit_TecnicodeLab_textChanged(const QString &arg1)
{
    QString filter_proResponsavel = ui->lineEdit_ProfResponsavel->text();
    QString filter_tecLab = ui->lineEdit_TecnicodeLab->text();
    QString filter_Localizacao = ui->lineEdit_Localizacao->text();
    QString filter_Codigo = ui->lineEdit_Codigo->text();
    QString prof, tec;

     tec = getUsuario(filter_tecLab,1);
     prof = getUsuario(filter_proResponsavel,2);

     modLab->setFilter(QString(""+prof+" and "+tec+" and IdLaboratorio like '%"+filter_Codigo+"%' "
     "and Localizacao like '%"+filter_Localizacao+"%' and laboratorio.Estado=true "));

    ui->tableView->setModel(modLab);
}

void ConsLab::on_lineEdit_Localizacao_textChanged(const QString &arg1)
{
    QString filter_proResponsavel = ui->lineEdit_ProfResponsavel->text();
    QString filter_tecLab = ui->lineEdit_TecnicodeLab->text();
    QString filter_Localizacao = ui->lineEdit_Localizacao->text();
    QString filter_Codigo = ui->lineEdit_Codigo->text();
    QString prof, tec;

     tec = getUsuario(filter_tecLab,1);
     prof = getUsuario(filter_proResponsavel,2);

     modLab->setFilter(QString(""+prof+" and "+tec+" and IdLaboratorio like '%"+filter_Codigo+"%' "
     "and Localizacao like '%"+filter_Localizacao+"%' and laboratorio.Estado=true "));


     ui->tableView->setModel(modLab);
}

void ConsLab::on_lineEdit_Codigo_textChanged(const QString &arg1)
{
    QString filter_proResponsavel = ui->lineEdit_ProfResponsavel->text();
    QString filter_tecLab = ui->lineEdit_TecnicodeLab->text();
    QString filter_Localizacao = ui->lineEdit_Localizacao->text();
    QString filter_Codigo = ui->lineEdit_Codigo->text();
    QString prof, tec;

     tec = getUsuario(filter_tecLab,1);
     prof = getUsuario(filter_proResponsavel,2);

     modLab->setFilter(QString(""+prof+" and "+tec+" and IdLaboratorio like '%"+filter_Codigo+"%' "
     "and Localizacao like '%"+filter_Localizacao+"%' and laboratorio.Estado=true "));

     ui->tableView->setModel(modLab);
}

void ConsLab::on_tableView_clicked(const QModelIndex &index)
{
    if (consequi1 != 0 || consequi2 != 0){
        ui->tableView->setColumnWidth(consequi2, 100);
        ui->tableView->setRowHeight(consequi1, 30);
        ui->tableView->resizeRowToContents(index.row());
        ui->tableView->resizeColumnToContents(index.column());
        consequi1 = index.row();
        consequi2 = index.column();
    } else{
        consequi1 = index.row();
        consequi2 = index.column();
        ui->tableView->resizeRowToContents(index.row());
        ui->tableView->resizeColumnToContents(index.column());
    }
}

void ConsLab::on_tableView_customContextMenuRequested(const QPoint &pos)
{
    if (perm != 4 && perm != 7 && perm != 9 && perm != 11 && perm != 12 && perm != 13 && perm != 15) {
       QModelIndex index = ui->tableView->indexAt(pos);
       idconsequi = ui->tableView->model()->index(index.row(), 3).data().toString();
       if(index.isValid()){
          QMenu *menu=new QMenu(this);
          QAction *alterarAction = new QAction("Alterar", this);
          QAction *removerAction = new QAction("Remover", this);
          connect(alterarAction,SIGNAL(triggered()),this,SLOT(alterar()));
          connect(removerAction,SIGNAL(triggered()),this,SLOT(remover()));
          menu->addAction(alterarAction);
          menu->addAction(removerAction);
          menu->popup(ui->tableView->viewport()->mapToGlobal(pos));
       }
    }
}

void ConsLab::alterar()
{
    altEqui = idconsequi;
    altEqui1 = 1;
    AlterarLab alterarlab;
    alterarlab.setModal(true);
    this->close();
    alterarlab.exec();
}

void ConsLab::remover()
{
    altEqui = idconsequi;
    altEqui1 = 1;
    RemoveLab removelab;
    removelab.setModal(true);
    this->close();
    removelab.exec();

}
