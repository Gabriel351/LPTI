#include "removeuser.h"
#include "ui_removeuser.h"
#include "menuremove.h"
#include "QSqlQuery"
#include "QCompleter"
#include "QVariant"
#include "dadoslogin.h"
#include "menucadasoption.h"
#include "consultaprincipal.h"



RemoveUser::RemoveUser(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::RemoveUser)
{
    ui->setupUi(this);

    QStringList CompletionList;
    QSqlQuery query;
    QString siape;


    query.prepare("select SIAPE from usuario where Estado=true ");
    if(query.exec()){
        while(query.next()){
            siape = query.value(0).toString();
            CompletionList << siape;
        }
    }

    StringCompleter = new QCompleter(CompletionList, this);
    StringCompleter->setCaseSensitivity(Qt::CaseInsensitive);
    ui->edit_Siape->setCompleter(StringCompleter);

    if(altEqui1 == 1){
        altEqui1 = 0;
        ui->edit_Siape->setText(altEqui);
    }

    ui->label_nome->setText(nome1);
}

RemoveUser::~RemoveUser()
{
    delete ui;
}

void RemoveUser::on_pushButton_clicked()
{
    MenuRemove menuremove;
    menuremove.setModal(true);
    menuremove.exec();
}

void RemoveUser::on_edit_Siape_textChanged(const QString &arg1)
{
    QSqlQuery query;
    QString siape, nome;
    siape = ui->edit_Siape->text();
    int count = 0;

    query.prepare("select Nome from usuario where SIAPE='"+siape+"' and Estado=true");
    if(query.exec()) {
        while(query.next()) {
            if (count == 0) {
                nome = query.value(0).toString();
            }
            count++;
        }
        if (count == 1) {
            ui->txt_Nome->setText(nome);
            ui->bnt_Confirma->setEnabled(true);
        } else{
            ui->txt_Nome->setText("");
            ui->bnt_Confirma->setEnabled(false);
        }
    }
}

void RemoveUser::on_bnt_Confirma_clicked()
{
    QSqlQuery query;
    QString siape;
    QPalette paleta = ui->txt_Erro->palette();

    siape = ui->edit_Siape->text();
    int num,count = 0;
    bool aux = true;


    //IdUsuario é uma chave estrangeira(int), SIAPE é varchar e é da outra tabela, necessário pegar
    //o valor de CodUsuario corresponde ao SIAPE
    query.prepare("select CodUsuario from Usuario where IdUsuario='"+siape+"' and Estado=true");
    if(query.exec()) {
        while(query.next()) {
            count++;
            num = query.value(0).toInt();
        }
        if (count != 1) {
            aux = false;
            paleta.setColor(QPalette::WindowText, Qt::red);
            ui->txt_Erro->setPalette(paleta);
            ui->txt_Erro->setText("Erro ao excluir usuário");
        }
    }

    if (login == siape){
        aux = false;
        paleta.setColor(QPalette::WindowText, Qt::red);
        ui->txt_Erro->setPalette(paleta);
        ui->txt_Erro->setText("Você não pode exclui o usuário \nque está sendo usado no momento");
    }

    if (aux == true) {
        query.prepare("update permissao set Estado=false where IdUsuario=':id'"+siape+"' and Estado=true");
        if(query.exec()) {
            paleta.setColor(QPalette::WindowText, Qt::darkGreen);
          ui->txt_Erro->setPalette(paleta);
            ui->txt_Erro->setText("Usuário excluido com sucesso.");
        } else {
            paleta.setColor(QPalette::WindowText, Qt::red);
            ui->txt_Erro->setPalette(paleta);
            ui->txt_Erro->setText("Erro ao excluir usuário");
        }
        query.prepare("update usuario set Estado=false where SIAPE='"+siape+"' and Estado=true");
        if(query.exec()) {
            paleta.setColor(QPalette::WindowText, Qt::darkGreen);
            ui->txt_Erro->setPalette(paleta);
            ui->txt_Erro->setText("Usuário excluido com sucesso.");
        } else {
            paleta.setColor(QPalette::WindowText, Qt::red);
            ui->txt_Erro->setPalette(paleta);
            ui->txt_Erro->setText("Erro ao excluir usuário.");
        }
    }

}

void RemoveUser::on_cadastro_2_clicked()
{
    if (perm != 11 && perm != 12 && perm != 13) {
        MenuCadasOption menucadasoption;
        menucadasoption.setModal(true);
        this->close();
        menucadasoption.exec();
    }
}

void RemoveUser::on_consulta_2_clicked()
{
    if (perm != 6 && perm != 6 && perm != 9 && perm != 10 && perm != 12 && perm != 14 && perm != 15) {
       ConsultaPrincipal consultaprincipal;
        consultaprincipal.setModal(true);
        this->close();
        consultaprincipal.exec();
    }
}
