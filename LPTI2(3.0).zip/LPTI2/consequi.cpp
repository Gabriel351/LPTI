﻿#include "consequi.h"
#include "ui_consequi.h"
#include "consultaprincipal.h"
#include "menucadasoption.h"
#include "consultaprincipal.h"
#include "QSqlQuery"
#include "nomesiapeproxmodel.h"
#include <cn.h>
#include "dadoslogin.h"
#include "alterarequip.h"
#include "removeequip.h"
#include "removeequip.h"


ConsEqui::ConsEqui(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ConsEqui)
{
    ui->setupUi(this);

    ui->tableView->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(ui->tableView, SIGNAL(customContextMenuRequested(QPoint)),
    SLOT(customMenuRequested(QPoint)));

    //Trazer os dados da tabela
    modEquipamento = new QSqlRelationalTableModel(this, cn::db());
    modEquipamento->setTable("equipamento");
    modEquipamento->setRelation(10, QSqlRelation("laboratorio", "CodLaboratorio", "IdLaboratorio"));

    modEquipamento->select();
    modEquipamento->setHeaderData(0, Qt::Horizontal, QObject::tr("CodEquipamento"));
    modEquipamento->setHeaderData(1, Qt::Horizontal, QObject::tr("Descrição"));
    modEquipamento->setHeaderData(2, Qt::Horizontal, QObject::tr("Data de\nAquisição"));
    modEquipamento->setHeaderData(3, Qt::Horizontal, QObject::tr("Fornecedor"));
    modEquipamento->setHeaderData(4, Qt::Horizontal, QObject::tr("Nota Fiscal"));
    modEquipamento->setHeaderData(5, Qt::Horizontal, QObject::tr("Tempo de Garantia"));
    modEquipamento->setHeaderData(6, Qt::Horizontal, QObject::tr("Data de\nNota Fiscal"));
    modEquipamento->setHeaderData(7, Qt::Horizontal, QObject::tr("Processo de Aquisição"));
    modEquipamento->setHeaderData(9, Qt::Horizontal, QObject::tr("Equipamento"));



    //Filtro
    ui->tableView->setModel(modEquipamento);
    ui->tableView->hideColumn(0);
    ui->tableView->hideColumn(11);
    modEquipamento->setFilter("EstadoExcluir=false");
    ui->tableView->hideColumn(12);

    QHeaderView *headerView = ui->tableView->horizontalHeader();
    headerView->swapSections(1, 9);
    headerView->swapSections(2, 9);
    headerView->swapSections(9, 8);
    headerView->swapSections(5, 9);
    headerView->swapSections(6, 10);
    headerView->swapSections(6, 4);
    ui->tableView->setEditTriggers(QAbstractItemView::NoEditTriggers);



}

ConsEqui::~ConsEqui()
{
    delete ui;
}

void ConsEqui::on_pushButton_4_clicked()
{
    ConsultaPrincipal consultaprincipal;
    consultaprincipal.setModal(true);
    consultaprincipal.exec();
}

void ConsEqui::on_cadastro_2_clicked()
{
    if (perm != 11 && perm != 12 && perm != 13) {
        MenuCadasOption menucadasoption;
        menucadasoption.setModal(true);
        this->close();
        menucadasoption.exec();
    }
}

void ConsEqui::on_consulta_2_clicked()
{
    if  (perm != 6 && perm != 6 && perm != 9 && perm != 10 && perm != 12 && perm != 14 && perm != 15) {
        ConsultaPrincipal consultaprincipal;
        consultaprincipal.setModal(true);
        this->close();
        consultaprincipal.exec();
    }
}

QString getLaboratorio(QString laboratorio) {
    QSqlQuery query;
    int  count = 0;
    QString num = "", tam;
    QVariant tipo;
    QString lab = "(", contagem = "";

    //chave estrangeira filtro
    if (laboratorio.size() != 0) {
        query.prepare("select CodLaboratorio from laboratorio where IdLaboratorio like '%"+laboratorio+"%' ");
       if (query.exec()) {

           //a ideia é juntar todos os CodLaboratorio(int) em uma string->num, e pega o tamanho de cada
          // CodLaboratorio->tipo, e colocar os tamanhos em outra string->contagem para lógica mais abaixo
            while (query.next()) {
                count++;
                num += query.value(0).toString();
                tam = query.value(0).toString();
                tipo = tam.size();
                // erro se ja foi adicionado 1000000000 de laboratorios(vai dar um numero de 2 digitos->10 casas) :p
                contagem += tipo.toString();
            }

          if (count != 0) {
             int a = 0;
             for (int i = 0; i < count; i++) {
                //olhar comentário no conslab, mesma lógica
                 tipo = contagem.mid(i,1);
                 lab += "Laboratorio="+num.mid(a,tipo.toInt())+" or ";
                 a += tipo.toInt();
             }
             lab.remove(lab.size() - 3, 3);
             lab += ")";
             return lab;
           } else {
              //nenhum filtro encontrado
              return "CodEquipamento = -1";
          }
     }
   } else {
        //filtro em branco
        return "Laboratorio like '%%'";
    }
}

void ConsEqui::on_codigo_textChanged(const QString &arg1)
{
    filtro();
}

void ConsEqui::on_ProcAquisicao_textChanged(const QString &arg1)
{
    filtro();
}

void ConsEqui::on_fornecedor_textChanged(const QString &arg1)
{
    filtro();
}

void ConsEqui::on_notaFiscal_textChanged(const QString &arg1)
{
    filtro();
}

void ConsEqui::on_localizacao_textChanged(const QString &arg1)
{
    filtro();
}

void ConsEqui::on_solicitante_textChanged(const QString &arg1)
{
    filtro();
}

void ConsEqui::on_dataAquisicao_stateChanged(int arg1)
{
    filtro();
}


void ConsEqui::on_dateAquisicao_dateChanged(const QDate &date)
{
    filtro();
}

void ConsEqui::on_dataGarantia_stateChanged(int arg1)
{
    filtro();
}

void ConsEqui::on_dateGarantia_dateChanged(const QDate &date)
{
    filtro();
}

void ConsEqui::on_dataNotaFiscal_stateChanged(int arg1)
{
    filtro();
}


void ConsEqui::on_dateNotaFiscal_dateChanged(const QDate &date)
{
    filtro();
}



void ConsEqui::filtro(){
    QString filter_dataAquisicao = ui->dateAquisicao->text();
    QString filter_dataGarantia = ui->dateGarantia->text();
    QString filter_dataNotaFiscal = ui->dateNotaFiscal->text();
    QString data1, data2, data3;
    QString codigo = ui->codigo->text();
    QString procAquisicao = ui->ProcAquisicao->text();
    QString fornecedor = ui->fornecedor->text();
    QString notaFiscal = ui->notaFiscal->text();
    QString localizacao = ui->localizacao->text();
    QString solicitante = ui->solicitante->text();
    QString lab;

    lab = getLaboratorio(localizacao);

    data1 = filter_dataAquisicao.right(4) + "-" + filter_dataAquisicao.mid(3, 2) + "-" + filter_dataAquisicao.left(2);
    data2 = filter_dataGarantia.right(4) + "-" + filter_dataGarantia.mid(3, 2) + "-" + filter_dataGarantia.left(2);
    data3 = filter_dataNotaFiscal.right(4) + "-" + filter_dataNotaFiscal.mid(3, 2) + "-" + filter_dataNotaFiscal.left(2);


    if (!ui->dataAquisicao->isChecked() && !ui->dataGarantia->isChecked() && !ui->dataNotaFiscal->isChecked()){
        // 0 0 0
        modEquipamento->setFilter(QString("IdEquipamento like '%"+codigo+"%' and ProcessoAquisicao like '%"+procAquisicao+"%'"
        "and Fornecedor like '%"+fornecedor+"%' and NotaFiscal like '%"+notaFiscal+"%' and EstadoExcluir=false "
        "and "+lab+" and  Solicitante like '%"+solicitante+"%' "));
    } else if (ui->dataAquisicao->isChecked() && !ui->dataGarantia->isChecked() && !ui->dataNotaFiscal->isChecked()){
        // 1 0 0
        modEquipamento->setFilter(QString("DataAquisicao like '%"+data1+"%' and IdEquipamento like '%"+codigo+"%' and ProcessoAquisicao like '%"+procAquisicao+"%' "
        "and Fornecedor like '%"+fornecedor+"%' and NotaFiscal like '%"+notaFiscal+"%' and EstadoExcluir=false "
        "and "+lab+" and  Solicitante like '%"+solicitante+"%' "));
    } else if (!ui->dataAquisicao->isChecked() && ui->dataGarantia->isChecked() && !ui->dataNotaFiscal->isChecked()){
        // 0 1 0
        modEquipamento->setFilter(QString("TempoGarantia like '%"+data2+"%'and IdEquipamento like '%"+codigo+"%' and ProcessoAquisicao like '%"+procAquisicao+"%'"
        "and Fornecedor like '%"+fornecedor+"%' and NotaFiscal like '%"+notaFiscal+"%' "
        "and "+lab+" and  Solicitante like '%"+solicitante+"%' and EstadoExcluir=false "));
    } else if (!ui->dataAquisicao->isChecked() && !ui->dataGarantia->isChecked() && ui->dataNotaFiscal->isChecked()){
        // 0 0 1
        modEquipamento->setFilter(QString("DataNotaFiscal like '%"+data3+"%' and IdEquipamento like '%"+codigo+"%' and ProcessoAquisicao like '%"+procAquisicao+"%' "
        "and Fornecedor like '%"+fornecedor+"%' and NotaFiscal like '%"+notaFiscal+"%' and EstadoExcluir=false "
        "and "+lab+" and  Solicitante like '%"+solicitante+"%' "));
    } else if (ui->dataAquisicao->isChecked() && ui->dataGarantia->isChecked() && !ui->dataNotaFiscal->isChecked()){
        // 1 1 0
        modEquipamento->setFilter(QString("DataAquisicao like '%"+data1+"%' and TempoGarantia like '%"+data2+"%'"
        "and IdEquipamento like '%"+codigo+"%' and ProcessoAquisicao like '%"+procAquisicao+"%' "
        "and Fornecedor like '%"+fornecedor+"%' and NotaFiscal like '%"+notaFiscal+"%' "
        "and "+lab+" and  Solicitante like '%"+solicitante+"%' and EstadoExcluir=false "));
    } else if (ui->dataAquisicao->isChecked() && !ui->dataGarantia->isChecked() && ui->dataNotaFiscal->isChecked()){
        // 1 0 1
        modEquipamento->setFilter(QString("DataAquisicao like '%"+data1+"%' and DataNotaFiscal like '%"+data3+"%' "
        "and IdEquipamento like '%"+codigo+"%' and ProcessoAquisicao like '%"+procAquisicao+"%' "
        "and Fornecedor like '%"+fornecedor+"%' and NotaFiscal like '%"+notaFiscal+"%' "
        "and "+lab+" and  Solicitante like '%"+solicitante+"%' and EstadoExcluir=false "));
    } else if (!ui->dataAquisicao->isChecked() && ui->dataGarantia->isChecked() && ui->dataNotaFiscal->isChecked()){
        // 0 1 1
        modEquipamento->setFilter(QString("IdEquipamento like '%"+codigo+"%' and ProcessoAquisicao like '%"+procAquisicao+"%' "
        "and Fornecedor like '%"+fornecedor+"%' and NotaFiscal like '%"+notaFiscal+"%' "
        "and "+lab+" and  Solicitante like '%"+solicitante+"%' "
        "and TempoGarantia like '%"+data2+"%' and DataNotaFiscal like '%"+data3+"%' and EstadoExcluir=false "));
    } else if (ui->dataAquisicao->isChecked() && ui->dataGarantia->isChecked() && ui->dataNotaFiscal->isChecked()){
        // 1 1 1
        modEquipamento->setFilter(QString("IdEquipamento like '%"+codigo+"%' and ProcessoAquisicao like '%"+procAquisicao+"%' "
        "and Fornecedor like '%"+fornecedor+"%' and NotaFiscal like '%"+notaFiscal+"%'  "
        "and "+lab+" and  Solicitante like '%"+solicitante+"%' "
        "and DataAquisicao like '%"+data1+"%' and TempoGarantia like '%"+data2+"%' and EstadoExcluir=false "
        "and DataNotaFiscal like '%"+data3+"%' "));
    } else{
        modEquipamento->setFilter(QString("EstadoExcluir=false"));
    }
}

void ConsEqui::on_tableView_clicked(const QModelIndex &index)
{
    if (consequi1 != 0 || consequi2 != 0){
        ui->tableView->setColumnWidth(consequi2, 100);
        ui->tableView->setRowHeight(consequi1, 30);
        ui->tableView->resizeRowToContents(index.row());
        ui->tableView->resizeColumnToContents(index.column());
        consequi1 = index.row();
        consequi2 = index.column();
    } else{
        consequi1 = index.row();
        consequi2 = index.column();
        ui->tableView->resizeRowToContents(index.row());
        ui->tableView->resizeColumnToContents(index.column());
    }
}

void ConsEqui::on_tableView_customContextMenuRequested(const QPoint &pos)
{
    if (perm != 5 && perm != 8 && perm != 10 && perm != 11 && perm != 12 && perm != 13 && perm != 14) {
        QModelIndex index = ui->tableView->indexAt(pos);
        idconsequi = ui->tableView->model()->index(index.row(), 9).data().toString();
        if(index.isValid()){
            QMenu *menu=new QMenu(this);
            QAction *alterarAction = new QAction("Alterar", this);
            QAction *removerAction = new QAction("Remover", this);
            connect(alterarAction,SIGNAL(triggered()),this,SLOT(alterar()));
            connect(removerAction,SIGNAL(triggered()),this,SLOT(remover()));
            menu->addAction(alterarAction);
            menu->addAction(removerAction);
            menu->popup(ui->tableView->viewport()->mapToGlobal(pos));
        }
    }
}

void ConsEqui::alterar()
{
    altEqui = idconsequi;
    altEqui1 = 1;
    AlterarEquip alterarequip;
    alterarequip.setModal(true);
    this->close();
    alterarequip.exec();
}

void ConsEqui::remover()
{
    altEqui = idconsequi;
    altEqui1 = 1;
    RemoveEquip removeequip;
    removeequip.setModal(true);
    this->close();
    removeequip.exec();
}

