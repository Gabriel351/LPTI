#ifndef CONSEQUI_H
#define CONSEQUI_H

#include <QDialog>
#include <QSqlRelationalTableModel>
#include <QSortFilterProxyModel>
#include <cn.h>
#include <QEvent>
#include <QDebug>

namespace Ui {
class ConsEqui;
}

class ConsEqui : public QDialog
{
    Q_OBJECT

public:
    explicit ConsEqui(QWidget *parent = 0);
    ~ConsEqui();

    QSqlRelationalTableModel * modEquipamento;
    QSortFilterProxyModel * proxyEquipamento;

private slots:
    void on_pushButton_4_clicked();

    void on_cadastro_2_clicked();

    void on_consulta_2_clicked();

    void on_codigo_textChanged(const QString &arg1);

    void on_ProcAquisicao_textChanged(const QString &arg1);

    void on_fornecedor_textChanged(const QString &arg1);

    void on_notaFiscal_textChanged(const QString &arg1);

    void on_localizacao_textChanged(const QString &arg1);

    void on_solicitante_textChanged(const QString &arg1);

    void on_dataAquisicao_stateChanged(int arg1);

    void on_dateAquisicao_dateChanged(const QDate &date);

    void on_dataGarantia_stateChanged(int arg1);

    void on_dateGarantia_dateChanged(const QDate &date);

    void on_dataNotaFiscal_stateChanged(int arg1);

    void filtro();

    void on_dateNotaFiscal_dateChanged(const QDate &date);

    void on_tableView_clicked(const QModelIndex &index);

    void on_tableView_customContextMenuRequested(const QPoint &pos);

    void alterar();

    void remover();

private:
    Ui::ConsEqui *ui;
};

#endif // CONSEQUI_H
