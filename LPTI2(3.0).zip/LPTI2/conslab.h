#ifndef CONSLAB_H
#define CONSLAB_H

#include <QDialog>
#include <QSqlRelationalTableModel>
#include <QSortFilterProxyModel>
#include <cn.h>

namespace Ui {
class ConsLab;
}

class ConsLab : public QDialog
{
    Q_OBJECT

public:
    explicit ConsLab(QWidget *parent = 0);
    ~ConsLab();
    QSqlRelationalTableModel * modLab;
    QSortFilterProxyModel * proxyLab;

private slots:
    void on_pushButton_4_clicked();

    void on_cadastro_2_clicked();

    void on_consulta_2_clicked();

    void on_lineEdit_ProfResponsavel_textChanged(const QString &arg1);

    void on_lineEdit_TecnicodeLab_textChanged(const QString &arg1);

    void on_lineEdit_Localizacao_textChanged(const QString &arg1);

    void on_lineEdit_Codigo_textChanged(const QString &arg1);

    void on_tableView_customContextMenuRequested(const QPoint &pos);

    void on_tableView_clicked(const QModelIndex &index);

    void alterar();

    void remover();

private:
    Ui::ConsLab *ui;
};

#endif // CONSLAB_H
