#include "alterarequip.h"
#include "ui_alterarequip.h"
#include "menualterar.h"
#include "QSqlQuery"
#include "menucadas.h"
#include "menuremove.h"
#include "menuprinc.h"
#include "menucadasoption.h"
#include "consultaprincipal.h"
#include "menuempres.h"
#include "dadoslogin.h"

AlterarEquip::AlterarEquip(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AlterarEquip)
{
    ui->setupUi(this);

    QStringList CompletionList;
    QSqlQuery query;
    QString cod;


    query.prepare("select IdEquipamento from equipamento where EstadoExcluir=false ");
    if(query.exec()){
        while(query.next()){
            cod = query.value(0).toString();
            CompletionList << cod;
        }
    }

    StringCompleter = new QCompleter(CompletionList, this);
    StringCompleter->setCaseSensitivity(Qt::CaseInsensitive);
    ui->cod->setCompleter(StringCompleter);

    QStringList CompletionList1;
    QString cod1;

    query.prepare("select IdLaboratorio from laboratorio ");
    if(query.exec()){
        while(query.next()){
            cod1 = query.value(0).toString();
            CompletionList1 << cod1;
        }
    }

    StringCompleter = new QCompleter(CompletionList1, this);
    StringCompleter->setCaseSensitivity(Qt::CaseInsensitive);
    ui->localizacao->setCompleter(StringCompleter);
}

AlterarEquip::~AlterarEquip()
{
    delete ui;
}

void AlterarEquip::on_pushButton_3_clicked()
{
    MenuAlterar menualterar;
    menualterar.setModal(true);
    menualterar.exec();
}

void AlterarEquip::on_cod_textChanged()
{
    QDate dataDefault = ui->data_fiscal->date();
    QString codigo = ui->cod->text();
    QString descricao;
    QString data_aquisicao;
    QString fornecedor;
    QString nota_fiscal;
    QString garantia;
    QString data_fiscal;
    QString aquisicao;
    QString solicitante;
    QString local;
    QDate data1,data2,data3;

    int count = 0;
    QSqlQuery query;


    //buscar dados no BD
    query.prepare("select Descricao,DataAquisicao,Fornecedor,NotaFiscal,TempoGarantia,DataNotaFiscal, "
    "ProcessoAquisicao,Solicitante from equipamento"
    " where IdEquipamento='"+codigo+"' and EstadoExcluir=false and EstadoEmpres=false");
    if(query.exec()) {
        while(query.next()) {
            count++;
            descricao = query.value(0).toString();
            data_aquisicao = query.value(1).toString();
            fornecedor = query.value(2).toString();
            nota_fiscal = query.value(3).toString();
            garantia = query.value(4).toString();
            data_fiscal = query.value(5).toString();
            aquisicao = query.value(6).toString();
            solicitante = query.value(7).toString();
        }
        if(count == 1) {
            //transformando datas do mysql->processo inverso ao do cadastrar. Apesar de ser feito de forma diferente,
            //pois não posso setar uma string nas datas, apenas date,time ou algum outro desse tipo
            data1.setDate(data_aquisicao.left(4).toInt(), data_aquisicao.mid(5,2).toInt(), data_aquisicao.right(2).toInt());
            data2.setDate(garantia.left(4).toInt(), garantia.mid(5,2).toInt(), garantia.right(2).toInt());
            data3.setDate(data_fiscal.left(4).toInt(), data_fiscal.mid(5,2).toInt(), data_fiscal.right(2).toInt());

            //setando valores
            ui->descricao->setText(descricao);
            ui->data_aquisicao->setDate(data1);
            ui->fornecedor->setText(fornecedor);
            ui->nota_fiscal->setText(nota_fiscal);
            ui->garantia->setDate(data2);
            ui->data_fiscal->setDate(data3);
            ui->aquisicao->setText(aquisicao);
            ui->solicitante->setText(solicitante);
        } else{
            ui->localizacao->setText("");
            ui->descricao->setText("");
            ui->data_aquisicao->setDate(dataDefault);
            ui->fornecedor->setText("");
            ui->nota_fiscal->setText("");
            ui->garantia->setDate(dataDefault);
            ui->data_fiscal->setDate(dataDefault);
            ui->aquisicao->setText("");
            ui->solicitante->setText("");

            ui->localizacao->setEnabled(false);
            ui->descricao->setEnabled(false);
            ui->data_aquisicao->setEnabled(false);
            ui->fornecedor->setEnabled(false);
            ui->nota_fiscal->setEnabled(false);
            ui->garantia->setEnabled(false);
            ui->data_fiscal->setEnabled(false);
            ui->aquisicao->setEnabled(false);
            ui->solicitante->setEnabled(false);
            ui->btn_confirma->setEnabled(false);
        }
    }
    count = 0;

    //inner join para o laboratório(usuario insere o id do lab, chave estrangeira é um int que se refere ao codigo do lab)
    query.prepare("select L.IdLaboratorio from equipamento as E inner join laboratorio as L where E.EstadoExcluir=false and L.CodLaboratorio=E.Laboratorio and E.IdEquipamento='"+codigo+"' ");
    if (query.exec()) {
        while(query.next()) {
            count++;
            local = query.value(0).toString();
        }
        if (count == 1) {
            ui->localizacao->setText(local);

            ui->descricao->setEnabled(true);
            ui->data_aquisicao->setEnabled(true);
            ui->fornecedor->setEnabled(true);
            ui->nota_fiscal->setEnabled(true);
            ui->garantia->setEnabled(true);
            ui->data_fiscal->setEnabled(true);
            ui->aquisicao->setEnabled(true);
            ui->solicitante->setEnabled(true);
            ui->btn_confirma->setEnabled(true);
            ui->localizacao->setEnabled(true);

        }
    }
}

void AlterarEquip::on_btn_confirma_clicked()
{
    QString codigo = ui->cod->text();
    QString descricao = ui->descricao->toPlainText();
    QString localizacao = ui->localizacao->text();
    QString data_aq = ui->data_aquisicao->text();
    QString fornecedor = ui->fornecedor->text();
    QString nota_fiscal = ui->nota_fiscal->text();
    QString garantia = ui->garantia->text();
    QString data_fiscal = ui->data_fiscal->text();
    QString aquisicao = ui->aquisicao->text();
    QString solicitante = ui->solicitante->text();
    bool aux = true;

    //chave estrangeira é int
    int lab;

    //mudança na data para ficar no padrão do mysql
    QString data1 = data_aq.right(4) + "-" + data_aq.mid(3, 2) + "-" + data_aq.left(2);
    QString data2 = data_fiscal.right(4) + "-" + data_fiscal.mid(3, 2) + "-" + data_fiscal.left(2);
    QString data3 = garantia.right(4) + "-" + garantia.mid(3, 2) + "-" + garantia.left(2);

    QPalette paleta;
    paleta.setColor(QPalette::WindowText, Qt::red);
    ui->mensagem->setPalette(paleta);


    //código, descrição e localização devem ser preenchidos
    if (codigo.size() == 0 || descricao.size() == 0 || localizacao.size() == 0) {
        ui->mensagem->setText("Os campos com asterisco não podem ficar em branco");
    } else {
        QSqlQuery query;
        int count = 0;
        aux = true;


        //verificando se o código do equipamento já existe
        //EstadoEmpres->false(não está emprestado)
        //EstadoExcluir->false(não é um equipamento que foi excluído)
        query.prepare("select CodEquipamento from equipamento where IdEquipamento='"+codigo+"' and EstadoExcluir=false");
        if (query.exec()) {
            while(query.next()) {
                count++;
            }
            if (count == 0) {
                aux = false;
                ui->mensagem->setText("Código do equipamento preenchido não existe");
            }
        }
        count = 0;


        //verificando se o código do laboratório existe
        query.prepare("select CodLaboratorio from laboratorio where IdLaboratorio='"+localizacao+"' and Estado=true");
        if (query.exec()) {
            while(query.next()) {
                lab = query.value(0).toInt();
                count++;
            }
            if (count != 1){
                aux = false;
                ui->mensagem->setText("Código do laboratório inserido não existe");
            }
        }
        count = 0;


        //tentativa de inserção no banco de dados
        if(aux == true) {
            query.prepare("update equipamento set Descricao=?,DataAquisicao=?,Fornecedor=?,NotaFiscal=?,TempoGarantia=?,"
            "DataNotaFiscal=?,ProcessoAquisicao=?,Solicitante=?,IdEquipamento=?,Laboratorio=? where IdEquipamento='"+codigo+"' ");
            query.addBindValue(descricao);
            query.addBindValue(data1);
            query.addBindValue(fornecedor);
            query.addBindValue(nota_fiscal);
            query.addBindValue(data3);
            query.addBindValue(data2);
            query.addBindValue(aquisicao);
            query.addBindValue(solicitante);
            query.addBindValue(codigo);
            query.addBindValue(lab);
            if (query.exec()) {
                paleta.setColor(QPalette::WindowText, Qt::darkGreen);
                ui->mensagem->setPalette(paleta);
                ui->mensagem->setText("Equipamento alterado com sucesso");
            } else {

                ui->mensagem->setText("erro ao alterar equipamento no banco de dados");
            }
        }
    }
}

/*void AlterarEquip::on_cadastrar_clicked()
{
    MenuCadas cadas;
    cadas.setModal(true);
    this->close();
    cadas.exec();
}

void AlterarEquip::on_remover_clicked()
{
    MenuRemove remove;
    remove.setModal(true);
    this->close();
    remove.exec();
}

void AlterarEquip::on_menu_clicked()
{
    MenuPrinc menu;
    menu.setModal(true);
    this->close();
    menu.exec();
}*/

void AlterarEquip::on_cadastro_2_clicked()
{
    if (perm != 11 && perm != 12 && perm != 13) {
        MenuCadasOption menucadasoption;
        menucadasoption.setModal(true);
        this->close();
        menucadasoption.exec();
    }
}

void AlterarEquip::on_consulta_2_clicked()
{
    if (perm != 6 && perm != 6 && perm != 9 && perm != 10 && perm != 12 && perm != 14 && perm != 15) {
       ConsultaPrincipal consultaprincipal;
        consultaprincipal.setModal(true);
        this->close();
        consultaprincipal.exec();
    }
}

void AlterarEquip::on_emprestimo_2_clicked()
{
    if (perm != 2 && perm != 6 && perm != 7 && perm != 8 && perm != 13 && perm != 14 && perm != 15) {
        MenuEmpres menuemp;
        menuemp.setModal(true);
        this->close();
        menuemp.exec();
    }
}
