#include "menuremove.h"
#include "ui_menuremove.h"
#include "menucadasoption.h"
#include "removeequip.h"
#include "removeuser.h"
#include "removelab.h"
#include "dadoslogin.h"
#include "consultaprincipal.h"
#include "menuempres.h"

MenuRemove::MenuRemove(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MenuRemove)
{
    ui->setupUi(this);

    if (perm == 1) {
        ui->pushButton->setStyleSheet("background-color: rgb(183, 253, 252)");
    } else {
        ui->pushButton->setStyleSheet("background-color: rgb(140, 160, 140)");
    }

    if (perm != 4 && perm != 7 && perm != 9 && perm != 11 && perm != 12 && perm != 13 && perm != 15) {
        ui->pushButton_2->setStyleSheet("background-color: rgb(183, 253, 252)");
    } else {
        ui->pushButton_2->setStyleSheet("background-color: rgb(140, 160, 140)");
    }

    if (perm != 5 && perm != 8 && perm != 10 && perm != 11 && perm != 12 && perm != 13 && perm != 14) {
        ui->pushButton_3->setStyleSheet("background-color: rgb(183, 253, 252)");
    } else {
        ui->pushButton_3->setStyleSheet("background-color: rgb(140, 160, 140)");
    }
}

MenuRemove::~MenuRemove()
{
    delete ui;
}

void MenuRemove::on_pushButton_clicked()
{
    if (perm == 1) {
        RemoveUser removeuser;
        removeuser.setModal(true);
        this->close();
        removeuser.exec();
    }
}

void MenuRemove::on_pushButton_2_clicked()
{
    if (perm != 4 && perm != 7 && perm != 9 && perm != 11 && perm != 12 && perm != 13 && perm != 15) {
      RemoveLab removelab;
      removelab.setModal(true);
      this->close();
      removelab.exec();
    }
}

void MenuRemove::on_pushButton_3_clicked()
{
    if (perm != 5 && perm != 8 && perm != 10 && perm != 11 && perm != 12 && perm != 13 && perm != 14) {
        RemoveEquip removeequip;
        removeequip.setModal(true);
        this->close();
        removeequip.exec();
    }
}

void MenuRemove::on_pushButton_4_clicked()
{
    MenuCadasOption menucadasoption;
    menucadasoption.setModal(true);
    menucadasoption.exec();
}

void MenuRemove::on_cadastro_2_clicked()
{
    if (perm != 11 && perm != 12 && perm != 13) {
        MenuCadasOption menucadasoption;
        menucadasoption.setModal(true);
        this->close();
        menucadasoption.exec();
    }
}



void MenuRemove::on_consulta_2_clicked()
{
    if (perm != 6 && perm != 6 && perm != 9 && perm != 10 && perm != 12 && perm != 14 && perm != 15) {
       ConsultaPrincipal consultaprincipal;
        consultaprincipal.setModal(true);
        this->close();
        consultaprincipal.exec();
    }
}

void MenuRemove::on_emprestimo_2_clicked()
{
    if (perm != 2 && perm != 6 && perm != 7 && perm != 8 && perm != 13 && perm != 14 && perm != 15) {
        MenuEmpres menuemp;
        menuemp.setModal(true);
        this->close();
        menuemp.exec();
    }
}
