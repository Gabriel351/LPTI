#ifndef CONSUSUARIOS_H
#define CONSUSUARIOS_H

#include <QDialog>
#include <QSqlRelationalTableModel>
#include <QSortFilterProxyModel>
#include <cn.h>

namespace Ui {
class ConsUsuarios;
}

class ConsUsuarios : public QDialog
{
    Q_OBJECT

public:
    explicit ConsUsuarios(QWidget *parent = 0);
    ~ConsUsuarios();
    QSqlRelationalTableModel * modUsuario;

private slots:
    void on_pushButton_3_clicked();

    void on_pushButton_clicked();

private:
    Ui::ConsUsuarios *ui;
};

#endif // CONSUSUARIOS_H
