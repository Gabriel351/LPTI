#include "consequi.h"
#include "ui_consequi.h"
#include "consultaprincipal.h"
#include "menucadasoption.h"
#include "consultaprincipal.h"
#include "dadoslogin.h"
#include "QSqlQuery"
#include "nomesiapeproxmodel.h"
#include <cn.h>

ConsEqui::ConsEqui(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ConsEqui)
{
    ui->setupUi(this);

    //Trazer os dados da tabela
    modEquipamento = new QSqlRelationalTableModel(this, cn::db());
    modEquipamento->setTable("equipamento");
    modEquipamento->setRelation(10, QSqlRelation("laboratorio", "CodLaboratorio", "IdLaboratorio"));



    modEquipamento->setHeaderData(1, Qt::Horizontal, QObject::tr("Código"));
    modEquipamento->setHeaderData(2, Qt::Horizontal, QObject::tr("Localização"));
    modEquipamento->setHeaderData(4, Qt::Horizontal, QObject::tr("Processo de\nAquisição"));
    modEquipamento->setHeaderData(5, Qt::Horizontal, QObject::tr("Fornecedor"));
    modEquipamento->setHeaderData(6, Qt::Horizontal, QObject::tr("Nota Fiscal"));
    modEquipamento->setHeaderData(7, Qt::Horizontal, QObject::tr("Solicitante"));
    modEquipamento->setHeaderData(8, Qt::Horizontal, QObject::tr("Data de Aquisição"));
    modEquipamento->setHeaderData(9, Qt::Horizontal, QObject::tr("Data de\nNota Fiscal"));
    //Filtro

    //modUsuario->setFilter(QString("Nome like '%sfwess%' "));
    modEquipamento->select();

    ui->tableView->setModel(modEquipamento);
}

ConsEqui::~ConsEqui()
{
    delete ui;
}

void ConsEqui::on_pushButton_4_clicked()
{
    ConsultaPrincipal consultaprincipal;
    consultaprincipal.setModal(true);
    consultaprincipal.exec();
}

void ConsEqui::on_cadastro_2_clicked()
{
    if (perm != 11 && perm != 12 && perm != 13) {
        MenuCadasOption menucadasoption;
        menucadasoption.setModal(true);
        this->close();
        menucadasoption.exec();
    }
}

void ConsEqui::on_consulta_2_clicked()
{
    if  (perm != 6 && perm != 6 && perm != 9 && perm != 10 && perm != 12 && perm != 14 && perm != 15) {
        ConsultaPrincipal consultaprincipal;
        consultaprincipal.setModal(true);
        this->close();
        consultaprincipal.exec();
    }
}


void ConsEqui::on_dataAquisicao_clicked()
{
    QString filter_dataAquisicao = ui->dateAquisicao->text();
    QString data1, data2, data3;

    data1 = filter_dataAquisicao.right(4) + "-" + filter_dataAquisicao.mid(3, 2) + "-" + filter_dataAquisicao.left(2);
    //QString data2 = data_fiscal.right(4) + "-" + data_fiscal.mid(3, 2) + "-" + data_fiscal.left(2);
    //QString data3 = garantia.right(4) + "-" + garantia.mid(3, 2) + "-" + garantia.left(2);

    if (ui->dataAquisicao->isChecked()){
        modEquipamento->setFilter(QString("DataAquisicao like '%"+data1+"%'" ));
    } else {
        modEquipamento->setFilter(QString());
    }
}
