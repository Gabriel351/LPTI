#ifndef CONSEQUI_H
#define CONSEQUI_H

#include <QDialog>
#include <QSqlRelationalTableModel>
#include <QSortFilterProxyModel>
#include <cn.h>

namespace Ui {
class ConsEqui;
}

class ConsEqui : public QDialog
{
    Q_OBJECT

public:
    explicit ConsEqui(QWidget *parent = 0);
    ~ConsEqui();
    QSqlRelationalTableModel * modEquipamento;
    QSortFilterProxyModel * proxyEquipamento;

private slots:
    void on_pushButton_4_clicked();

    void on_cadastro_2_clicked();

    void on_consulta_2_clicked();

 /*   void on_ProcAquisicao_textChanged(const QString &arg1);

    void on_fornecedor_textChanged(const QString &arg1);

    void on_notaFiscal_textChanged(const QString &arg1);

    void on_localizacao_textChanged(const QString &arg1);

    void on_solicitante_textChanged(const QString &arg1);

    void on_codigo_textEdited(const QString &arg1);*/

    void on_dataAquisicao_clicked();

private:
    Ui::ConsEqui *ui;
};

#endif // CONSEQUI_H
