#ifndef CONSUSUARIOS_H
#define CONSUSUARIOS_H

#include <QDialog>
#include <QSqlRelationalTableModel>
#include <QSortFilterProxyModel>
#include <cn.h>

namespace Ui {
class ConsUsuarios;
}

class ConsUsuarios : public QDialog
{
    Q_OBJECT

public:
    explicit ConsUsuarios(QWidget *parent = 0);
    ~ConsUsuarios();
    QSqlRelationalTableModel * modUsuario;
    QSortFilterProxyModel * proxyUsuario;

private slots:
    void on_pushButton_3_clicked();

    void on_pushButton_clicked();

    void on_lineEdit_2_textChanged(const QString &arg1);

    void on_nome_textChanged(const QString &arg1);

    void on_siape_textChanged(const QString &arg1);

    void on_email_textChanged(const QString &arg1);

    void alterar();

    void remover();

    void on_tableView_customContextMenuRequested(const QPoint &pos);

    void on_tableView_clicked(const QModelIndex &index);

private:
    Ui::ConsUsuarios *ui;
};

#endif // CONSUSUARIOS_H
