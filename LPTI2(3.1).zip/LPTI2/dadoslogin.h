#ifndef DADOSLOGIN_H
#define DADOSLOGIN_H
#include "QString"

extern int perm, consequi1, consequi2, altEqui1;
extern QString login,nome1, altEqui, idconsequi;

class DadosLogin
{
public:
    DadosLogin();

};



#endif // DADOSLOGIN_H
