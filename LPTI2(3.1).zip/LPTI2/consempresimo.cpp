#include "consempresimo.h"
#include "ui_consempresimo.h"
#include "menuempres.h"
#include "menucadasoption.h"
#include "consultaprincipal.h"
#include "dadoslogin.h"


ConsEmpresimo::ConsEmpresimo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ConsEmpresimo)
{
    ui->setupUi(this);
}

ConsEmpresimo::~ConsEmpresimo()
{
    delete ui;
}

void ConsEmpresimo::on_pushButton_4_clicked()
{
    MenuEmpres menuempres;
    menuempres.setModal(true);
    menuempres.exec();
}

void ConsEmpresimo::on_cadastro_2_clicked()
{
    if (perm != 11 && perm != 12 && perm != 13) {
        MenuCadasOption menucadasoption;
        menucadasoption.setModal(true);
        this->close();
        menucadasoption.exec();
    }
}

void ConsEmpresimo::on_consulta_2_clicked()
{
    if (perm != 6 && perm != 6 && perm != 9 && perm != 10 && perm != 12 && perm != 14 && perm != 15) {
       ConsultaPrincipal consultaprincipal;
        consultaprincipal.setModal(true);
        this->close();
        consultaprincipal.exec();
    }
}
