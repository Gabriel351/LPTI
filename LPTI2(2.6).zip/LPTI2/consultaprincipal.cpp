#include "consultaprincipal.h"
#include "ui_consultaprincipal.h"
#include "consusuarios.h"
#include "conslab.h"
#include "consequi.h"
#include "menuprinc.h"
#include "menucadasoption.h"
#include "consultaprincipal.h"
#include "menuempres.h"
#include "dadoslogin.h"

ConsultaPrincipal::ConsultaPrincipal(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ConsultaPrincipal)
{
    ui->setupUi(this);
}

ConsultaPrincipal::~ConsultaPrincipal()
{
    delete ui;
}

void ConsultaPrincipal::on_pushButton_3_clicked()
{
    ConsUsuarios consusuarios;
    consusuarios.setModal(true);
    consusuarios.exec();
}

void ConsultaPrincipal::on_pushButton_2_clicked()
{
    ConsLab conslab;
    conslab.setModal(true);
    conslab.exec();
}

void ConsultaPrincipal::on_pushButton_clicked()
{
    ConsEqui consequi;
    consequi.setModal(true);
    consequi.exec();
}

void ConsultaPrincipal::on_pushButton_4_clicked()
{
    MenuPrinc menuprinc;
    menuprinc.setModal(true);
    menuprinc.exec();
}

void ConsultaPrincipal::on_cadastro_2_clicked()
{
    if (perm != 11 && perm != 12 && perm != 13) {
        MenuCadasOption menucadasoption;
        menucadasoption.setModal(true);
        this->close();
        menucadasoption.exec();
    }
}

void ConsultaPrincipal::on_consulta_2_clicked()
{
    if  (perm != 6 && perm != 6 && perm != 9 && perm != 10 && perm != 12 && perm != 14 && perm != 15) {
        ConsultaPrincipal consultaprincipal;
        consultaprincipal.setModal(true);
        this->close();
        consultaprincipal.exec();
    }
}


void ConsultaPrincipal::on_emprestimo_2_clicked()
{
    if (perm != 2 && perm != 6 && perm != 7 && perm != 8 && perm != 13 && perm != 14 && perm != 15) {
        MenuEmpres menuemp;
        menuemp.setModal(true);
        this->close();
        menuemp.exec();
    }
}
