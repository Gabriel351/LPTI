#include "alteraruser.h"
#include "ui_alteraruser.h"
#include "menualterar.h"
#include "QSqlQuery"
#include "QCompleter"
#include "QVariant"
#include "dadoslogin.h"
#include "menucadasoption.h"
#include "consultaprincipal.h"
#include "dadoslogin.h"


AlterarUser::AlterarUser(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AlterarUser)
{
    ui->setupUi(this);

    QStringList CompletionList;
    QSqlQuery query;
    QString siape;


    query.prepare("select SIAPE from usuario where Estado=true ");
    if(query.exec()){
        while(query.next()){
            siape = query.value(0).toString();
            CompletionList << siape;
        }
    }

    StringCompleter = new QCompleter(CompletionList, this);
    StringCompleter->setCaseSensitivity(Qt::CaseInsensitive);
    ui->edit_Siape->setCompleter(StringCompleter);
}

AlterarUser::~AlterarUser()
{
    delete ui;
}

void AlterarUser::on_bnt_Voltar_clicked()
{
    MenuAlterar menualterar;
    menualterar.setModal(true);
    menualterar.exec();
}

void AlterarUser::on_edit_Siape_textChanged(const QString &arg1)
{
    QString siape = ui->edit_Siape->text();
    QString nome, email;
    int permissao, codUsuario, cargo;
    int count = 0;

    QSqlQuery query;
    //buscar dados banco de dados
    query.prepare("select Nome,Email,CodUsuario,Cargo from usuario where SIAPE='"+siape+"' and Estado=true ");
    if(query.exec()) {
        while(query.next()) {
            if (count == 0) {
                nome = query.value(0).toString();
                email = query.value(1).toString();
                codUsuario = query.value(2).toInt();
                cargo = query.value(3).toInt();
            }
            count++;
        }
        if (count == 1) {
            ui->edit_Nome->setText(nome);
            ui->edit_Email->setText(email);
        }
    }
    QString scodUsuario = QString::number(codUsuario);
    count = 0;
    query.prepare("select Permissao from permissao where IdUsuario='"+scodUsuario+"' and Estado=true ");
    if(query.exec()){
        while(query.next()){
            if(count == 0){
                permissao = query.value(0).toInt();
            }
            count++;
        }
        if(count == 1){
            if(permissao == 1){
                ui->check_SuperU->setChecked(true);
                ui->check_CadasEqui->setChecked(true);
                ui->check_CadasLab->setChecked(true);
                ui->check_Consultar->setChecked(true);
                ui->check_Emprestar->setChecked(true);
            } else if (permissao == 2){
                ui->check_SuperU->setChecked(false);
                ui->check_CadasEqui->setChecked(true);
                ui->check_CadasLab->setChecked(true);
                ui->check_Consultar->setChecked(true);
                ui->check_Emprestar->setChecked(false);
            } else if (permissao == 3){
                ui->check_SuperU->setChecked(false);
                ui->check_CadasEqui->setChecked(true);
                ui->check_CadasLab->setChecked(true);
                ui->check_Consultar->setChecked(false);
                ui->check_Emprestar->setChecked(true);
            } else if (permissao == 4){
                ui->check_SuperU->setChecked(false);
                ui->check_CadasEqui->setChecked(true);
                ui->check_CadasLab->setChecked(false);
                ui->check_Consultar->setChecked(true);
                ui->check_Emprestar->setChecked(true);
            } else if (permissao == 5){
                ui->check_SuperU->setChecked(false);
                ui->check_CadasEqui->setChecked(false);
                ui->check_CadasLab->setChecked(true);
                ui->check_Consultar->setChecked(true);
                ui->check_Emprestar->setChecked(true);
            } else if (permissao == 6){
                ui->check_SuperU->setChecked(false);
                ui->check_CadasEqui->setChecked(true);
                ui->check_CadasLab->setChecked(true);
                ui->check_Consultar->setChecked(false);
                ui->check_Emprestar->setChecked(false);
            } else if (permissao == 7){
                ui->check_SuperU->setChecked(false);
                ui->check_CadasEqui->setChecked(true);
                ui->check_CadasLab->setChecked(false);
                ui->check_Consultar->setChecked(true);
                ui->check_Emprestar->setChecked(false);
            } else if (permissao == 8){
                ui->check_SuperU->setChecked(false);
                ui->check_CadasEqui->setChecked(false);
                ui->check_CadasLab->setChecked(true);
                ui->check_Consultar->setChecked(true);
                ui->check_Emprestar->setChecked(false);
            } else if (permissao == 9){
                ui->check_SuperU->setChecked(false);
                ui->check_CadasEqui->setChecked(true);
                ui->check_CadasLab->setChecked(false);
                ui->check_Consultar->setChecked(false);
                ui->check_Emprestar->setChecked(true);
            } else if (permissao == 10){
                ui->check_SuperU->setChecked(false);
                ui->check_CadasEqui->setChecked(false);
                ui->check_CadasLab->setChecked(true);
                ui->check_Consultar->setChecked(false);
                ui->check_Emprestar->setChecked(true);
            } else if (permissao == 11){
                ui->check_SuperU->setChecked(false);
                ui->check_CadasEqui->setChecked(false);
                ui->check_CadasLab->setChecked(false);
                ui->check_Consultar->setChecked(true);
                ui->check_Emprestar->setChecked(true);
            } else if (permissao == 12){
                ui->check_SuperU->setChecked(false);
                ui->check_CadasEqui->setChecked(false);
                ui->check_CadasLab->setChecked(false);
                ui->check_Consultar->setChecked(false);
                ui->check_Emprestar->setChecked(true);
            } else if (permissao == 13){
                ui->check_SuperU->setChecked(false);
                ui->check_CadasEqui->setChecked(false);
                ui->check_CadasLab->setChecked(false);
                ui->check_Consultar->setChecked(true);
                ui->check_Emprestar->setChecked(false);
            } else if (permissao == 14){
                ui->check_SuperU->setChecked(false);
                ui->check_CadasEqui->setChecked(false);
                ui->check_CadasLab->setChecked(true);
                ui->check_Consultar->setChecked(false);
                ui->check_Emprestar->setChecked(false);
            } else if (permissao == 15){
                ui->check_SuperU->setChecked(false);
                ui->check_CadasEqui->setChecked(true);
                ui->check_CadasLab->setChecked(false);
                ui->check_Consultar->setChecked(false);
                ui->check_Emprestar->setChecked(false);
            } else if (permissao == 16){
                ui->check_SuperU->setChecked(false);
                ui->check_CadasEqui->setChecked(true);
                ui->check_CadasLab->setChecked(true);
                ui->check_Consultar->setChecked(true);
                ui->check_Emprestar->setChecked(true);
            } else{

            }
            if(cargo == 1){
                ui->radio_Professor->setChecked(true);
            } else if (cargo == 0){
                ui->radio_Tecnico->setChecked(true);
            }

            ui->edit_Nome->setEnabled(true);
            ui->edit_Email->setEnabled(true);
            ui->check_SuperU->setEnabled(true);
            ui->check_CadasEqui->setEnabled(true);
            ui->check_CadasLab->setEnabled(true);
            ui->check_Consultar->setEnabled(true);
            ui->check_Emprestar->setEnabled(true);
            ui->radio_Professor->setEnabled(true);
            ui->radio_Tecnico->setEnabled(true);
            ui->bnt_Alterar->setEnabled(true);

        } else{
            // Não encontrado
            ui->edit_Nome->setEnabled(false);
            ui->edit_Email->setEnabled(false);
            ui->check_SuperU->setEnabled(false);
            ui->check_CadasEqui->setEnabled(false);
            ui->check_CadasLab->setEnabled(false);
            ui->check_Consultar->setEnabled(false);
            ui->check_Emprestar->setEnabled(false);
            ui->radio_Professor->setEnabled(false);
            ui->radio_Tecnico->setEnabled(false);
            ui->bnt_Alterar->setEnabled(false);

            ui->check_SuperU->setChecked(false);
            ui->check_CadasEqui->setChecked(false);
            ui->check_CadasLab->setChecked(false);
            ui->check_Consultar->setChecked(false);
            ui->check_Emprestar->setChecked(false);
            ui->radio_Professor->setChecked(false);
            ui->radio_Tecnico->setChecked(false);
            ui->bnt_Alterar->setChecked(false);
            ui->edit_Nome->setText("");
            ui->edit_Email->setText("");
        }
    }
}


void AlterarUser::on_bnt_Alterar_clicked()
{
    QString nome = ui->edit_Nome->text();
    QString email = ui->edit_Email->text();
    QString siape = ui->edit_Siape->text();
    QString id;
    QSqlQuery query;
    QPalette palette = ui->txt_Erro->palette();


    query.prepare("select CodUsuario from usuario where SIAPE='"+siape+"' and Estado=true ");
    if (query.exec()) {
        while(query.next()) {
            id = query.value(0).toString();
        }
    }
    bool aux = true;
    if (siape == login){
        aux = false;
        palette.setColor(QPalette::WindowText, Qt::red);
        ui->txt_Erro->setPalette(palette);
        ui->txt_Erro->setText("Erro ao atribuir nome, email ou cargo");
    }
    if (nome.size() != 0 && aux == true){
        if (email.size() != 0){
            if (ui->check_SuperU->isChecked() || ui->check_CadasEqui->isChecked() || ui->check_CadasLab->isChecked() || ui->check_Consultar->isChecked() || ui->check_Emprestar->isChecked()){
                query.prepare("update usuario set Nome=?,Email=?,Cargo=? where SIAPE='"+siape+"' and Estado=true ");
                query.addBindValue(nome);
                query.addBindValue(email);
                if(ui->radio_Professor->isChecked()){
                    query.addBindValue(1);
                } else{
                    query.addBindValue(0);
                }
                if(query.exec()){

                } else{
                    palette.setColor(QPalette::WindowText, Qt::red);
                    ui->txt_Erro->setPalette(palette);
                    ui->txt_Erro->setText("Erro ao atribuir nome, email ou cargo");
                }

                if(ui->check_SuperU->isChecked()){
                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' and Estado=true ");
                    query.addBindValue(1);
                    // Permissao de Super Usuário = 1
                } else if(ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' and Estado=true ");
                    query.addBindValue(2);
                    // Permissao tudo menos emprestar = 2
                } else if(ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' and Estado=true ");
                    query.addBindValue(3);
                    // Permissao tudo menos consultar = 3
                } else if(ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' and Estado=true ");
                    query.addBindValue(4);
                    // Permissao tudo menos cadastrar laboratorio = 4
                } else if(!ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' and Estado=true");
                    query.addBindValue(5);
                    // Permissao tudo menos cadastrar equipamento = 5
                } else if(ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' and Estado=true");
                    query.addBindValue(6);
                    // Permissao tudo menos emprestar e consultar = 6
                } else if(ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' and Estado=true");
                    query.addBindValue(7);
                    // Permissao tudo menos emprestar e cadastrar laboratorio = 7
                } else if(!ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' and Estado=true");
                    query.addBindValue(8);
                    // Permissao tudo menos emprestar e cadastrar equipamento = 8
                } else if(ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' and Estado=true");
                    query.addBindValue(9);
                    // Permissao tudo menos consultar e cadastrar laboratorio = 9
                } else if(!ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' and Estado=true");
                    query.addBindValue(10);
                    // Permissao tudo menos consultar e cadastrar equipamento = 10
                } else if(!ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' and Estado=true");
                    query.addBindValue(11);
                    // Permissao tudo menos cadastrar laboratorio e cadastrar equipamento = 11
                } else if(!ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){
                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' and Estado=true");
                    query.addBindValue(12);
                    // Permissao apenas de emprestar = 12
                } else if(!ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' ");
                    query.addBindValue(13);
                    // Permissao apenas de consultar = 13
                } else if(!ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' and Estado=true");
                    query.addBindValue(14);
                    // Permissao apenas de cadastrar laboratorio = 14
                } else if(ui->check_CadasEqui->isChecked() && !ui->check_CadasLab->isChecked() && !ui->check_Consultar->isChecked() && !ui->check_Emprestar->isChecked()){
                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' and Estado=true");
                    query.addBindValue(15);
                    // Permissao apenas de cadastrar equipamentos = 15
                } else if (ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked() && !ui->check_SuperU->isChecked()) {
                    query.prepare("update permissao set Permissao=? where IdUsuario='"+id+"' and Estado=true");
                    query.addBindValue(16);
                }else{
                    palette.setColor(QPalette::WindowText, Qt::red);
                    ui->txt_Erro->setPalette(palette);
                    ui->txt_Erro->setText("Erro ao cadastrar permissão(ões).");
                }
                if (query.exec()) {
                    palette.setColor(QPalette::WindowText, Qt::green);
                    ui->txt_Erro->setPalette(palette);
                    ui->txt_Erro->setText("Alteração feita com sucesso.");
                } else {
                    palette.setColor(QPalette::WindowText, Qt::red);
                    ui->txt_Erro->setPalette(palette);
                    ui->txt_Erro->setText("falha ao conectar no banco de dados");
                }
            } else{
                palette.setColor(QPalette::WindowText, Qt::red);
                ui->txt_Erro->setPalette(palette);
                ui->txt_Erro->setText("Pelo menos uma permissao deve ser concedida.");
            }
        } else {
            palette.setColor(QPalette::WindowText, Qt::red);
            ui->txt_Erro->setPalette(palette);
            ui->txt_Erro->setText("Campo e-mail não pode ficar vazio.");
        }
    } else {
        palette.setColor(QPalette::WindowText, Qt::red);
        ui->txt_Erro->setPalette(palette);
        ui->txt_Erro->setText("Campo nome não pode ficar vazio.");
    }



}

void AlterarUser::on_check_SuperU_clicked()
{
    if(ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){

    } else{
        ui->check_CadasEqui->setChecked(true);
        ui->check_CadasLab->setChecked(true);
        ui->check_Consultar->setChecked(true);
        ui->check_Emprestar->setChecked(true);
    }
}

void AlterarUser::on_check_CadasLab_clicked()
{
    if(ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){

    } else{
        ui->check_SuperU->setCheckable(true);
        ui->check_SuperU->setChecked(false);
    }
}

void AlterarUser::on_check_CadasEqui_clicked()
{
    if(ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){

    } else{
        ui->check_SuperU->setCheckable(true);
        ui->check_SuperU->setChecked(false);
    }
}

void AlterarUser::on_check_Consultar_clicked()
{
    if(ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){

    } else{
        ui->check_SuperU->setCheckable(true);
        ui->check_SuperU->setChecked(false);
    }
}

void AlterarUser::on_check_Emprestar_clicked()
{
    if(ui->check_CadasEqui->isChecked() && ui->check_CadasLab->isChecked() && ui->check_Consultar->isChecked() && ui->check_Emprestar->isChecked()){

    } else{
        ui->check_SuperU->setCheckable(true);
        ui->check_SuperU->setChecked(false);
    }
}

void AlterarUser::on_cadastro_2_clicked()
{
    if (perm != 11 && perm != 12 && perm != 13) {
        MenuCadasOption menucadasoption;
        menucadasoption.setModal(true);
        this->close();
        menucadasoption.exec();
    }
}

void AlterarUser::on_consulta_2_clicked()
{
    if (perm != 6 && perm != 6 && perm != 9 && perm != 10 && perm != 12 && perm != 14 && perm != 15) {
       ConsultaPrincipal consultaprincipal;
        consultaprincipal.setModal(true);
        this->close();
        consultaprincipal.exec();
    }
}
