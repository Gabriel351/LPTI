#ifndef DADOSLOGIN_H
#define DADOSLOGIN_H

extern int perm;

class DadosLogin
{
public:
    DadosLogin();

};



#endif // DADOSLOGIN_H
