#ifndef MENUPRINC_H
#define MENUPRINC_H

#include <QDialog>

namespace Ui {
class MenuPrinc;
}

class MenuPrinc : public QDialog
{
    Q_OBJECT

public:
    explicit MenuPrinc(QWidget *parent = 0);
    ~MenuPrinc();

private slots:
    void on_cadastro_clicked();

    void on_consulta_clicked();

    void on_emprestimo_clicked();

    void on_desconectar_clicked();


private:
    Ui::MenuPrinc *ui;
};

#endif // MENUPRINC_H
