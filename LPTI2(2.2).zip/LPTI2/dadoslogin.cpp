#include "dadoslogin.h"
#include "QString"

int perm;

DadosLogin::DadosLogin()
{
}




