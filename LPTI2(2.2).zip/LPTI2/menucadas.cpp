#include "menucadas.h"
#include "ui_menucadas.h"
#include "cadasuser.h"
#include "cadaslab.h"
#include "cadasequip.h"
#include "menucadasoption.h"
#include "dadoslogin.h"

MenuCadas::MenuCadas(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MenuCadas)
{
    ui->setupUi(this);

    if (perm == 1) {
        ui->pushButton->setStyleSheet("background-color: rgb(183, 253, 252)");
    } else {
        ui->pushButton->setStyleSheet("background-color: rgb(140, 160, 140)");
    }

    if (perm != 4 && perm != 7 && perm != 9 && perm != 11 && perm != 12 && perm != 13 && perm != 15) {
        ui->pushButton_2->setStyleSheet("background-color: rgb(183, 253, 252)");
    } else {
        ui->pushButton_2->setStyleSheet("background-color: rgb(140, 160, 140)");
    }

    if (perm != 5 && perm != 8 && perm != 10 && perm != 11 && perm != 12 && perm != 13 && perm != 14) {
        ui->pushButton_3->setStyleSheet("background-color: rgb(183, 253, 252)");
    } else {
        ui->pushButton_3->setStyleSheet("background-color: rgb(140, 160, 140)");
    }
}

MenuCadas::~MenuCadas()
{
    delete ui;
}

void MenuCadas::on_pushButton_clicked()
{
    if (perm == 1) {
        CadasUser cadasuser;
        cadasuser.setModal(true);
        this->close();
        cadasuser.exec();
    }
}

void MenuCadas::on_pushButton_2_clicked()
{
    if (perm != 4 && perm != 7 && perm != 9 && perm != 11 && perm != 12 && perm != 13 && perm != 15) {
        CadasLab cadaslab;
        cadaslab.setModal(true);
        this->close();
        cadaslab.exec();
    }
}


void MenuCadas::on_pushButton_3_clicked()
{
    if (perm != 5 && perm != 8 && perm != 10 && perm != 11 && perm != 12 && perm != 13 && perm != 14) {
        CadasEquip cadasequip;
        cadasequip.setModal(true);
        this->close();
        cadasequip.exec();
    }
}

void MenuCadas::on_pushButton_4_clicked()
{
    MenuCadasOption menucadasoption;
    menucadasoption.setModal(true);
    menucadasoption.exec();
}
