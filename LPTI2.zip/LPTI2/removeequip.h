#ifndef REMOVEEQUIP_H
#define REMOVEEQUIP_H

#include <QDialog>
#include <QCompleter>

namespace Ui {
class RemoveEquip;
}

class RemoveEquip : public QDialog
{
    Q_OBJECT

public:
    explicit RemoveEquip(QWidget *parent = 0);
    ~RemoveEquip();

private slots:
     void on_pushButton_clicked();

     void on_btn_confirma_clicked();

     void on_cod_equip_textChanged();

private:
    Ui::RemoveEquip *ui;
    QCompleter *StringCompleter;
};

#endif // REMOVEEQUIP_H
